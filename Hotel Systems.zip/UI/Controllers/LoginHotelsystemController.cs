﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace UI.Controllers
{
    public class LoginHotelsystemController : Controller
    {
        // GET: LoginHotelsystem
        public ActionResult loginEmploye()
        {
            return View();
        }
        public ActionResult REGISTER()
        {
            return View();
        }

    }
}